from controller import Robot, Keyboard, DistanceSensor


# Constants
#TIME_STEP = 32  # Simulation time step in milliseconds
WHEEL_RADIUS = 0.1  # Radius of the wheels in meters (10cm)
L = 0.471  # Half of the robot's length in meters
W = 0.376  # Half of the robot's width in meters
MAX_VELOCITY = 10.0  # Maximum velocity allowed for the wheels

# Initialize the robot
robot = Robot()

# Get simulation time step
timestep = int(robot.getBasicTimeStep())

# Get the DistanceSensor device
sensor = robot.getDevice('sensor')
emitter = robot.getDevice("score_emitter")
sensor.enable(timestep)
previous_detected = False
score = 0
score_to_send = 2
# Initialize the keyboard
keyboard = Keyboard()
#keyboard.enable(TIME_STEP)
keyboard.enable(timestep)


# Get motor devices
wheel5 = robot.getDevice("wheel5")  # Front-right wheel
wheel6 = robot.getDevice("wheel6")  # Front-left wheel
wheel7 = robot.getDevice("wheel7")  # Rear-right wheel
wheel8 = robot.getDevice("wheel8")  # Rear-left wheel

# Set motors to velocity control mode
for wheel in [wheel5, wheel6, wheel7, wheel8]:
    wheel.setPosition(float('inf'))  # Enable velocity control
    wheel.setVelocity(0)  # Set initial velocity to 0

def set_wheel_velocity(v1, v2, v3, v4):
    """Set the velocity of all wheels."""
    wheel5.setVelocity(v1)
    wheel6.setVelocity(v2)
    wheel7.setVelocity(v3)
    wheel8.setVelocity(v4)

# lookupTable 轉成程式用的格式
lookup_table = [
    (1000, 0.00),
    (800, 10),
    (400, 10),
    (0, 0.00)
]

def ad_to_distance(ad_value):
    # 假設AD值遞減，距離遞增
    for i in range(len(lookup_table)-1):
        a0, d0 = lookup_table[i]
        a1, d1 = lookup_table[i+1]
        if a1 <= ad_value <= a0:
            # 線性插值
            return d0 + (d1 - d0) * (ad_value - a0) / (a1 - a0)
    # 超出範圍時回傳極值
    if ad_value > lookup_table[0][0]:
        return lookup_table[0][1]
    return lookup_table[-1][1]
    
# Main loop
print("Use 'W', 'A', 'S', 'D' keys to control the robot.")
print("S: Move forward, W: Move backward, A: Turn left, D: Turn right.")
print("Press 'Q' to quit.")

#while robot.step(TIME_STEP) != -1:
while robot.step(timestep) != -1:

    key = keyboard.getKey()  # Read the key pressed
    # Read DistanceSensor value
    sensor_value = sensor.getValue()
    #print(sensor_value)
    distance = ad_to_distance(sensor_value)
    current_time = robot.getTime()
    #print(sensor_value)
    # Check if the ball blocks the sensor (you may need to adjust the threshold based on your sensor's range)
    currently_detected = distance > 5
    if distance != 0:
        print(distance)
    if currently_detected and not previous_detected:
        score += score_to_send
        previous_detected = True       
        emitter.send(str(score_to_send).encode('utf-8'))
        print(f"得分!當前分數{score}")
       
    if key == ord('L') or key == ord('l'):
        print(sensor_value)
    if key == ord('M') or key == ord('m'):
        print("m")
    if key == ord('K') or key == ord('k'):
        print("k")
    if key == ord('O') or key == ord('o'):
        previous_detected = False
        
    if key == ord('S') or key == ord('s'):
        # Move forward
        velocity = MAX_VELOCITY
        set_wheel_velocity(velocity, velocity, velocity, velocity)
    elif key == ord('W') or key == ord('w'):
        # Move backward
        velocity = -MAX_VELOCITY
        set_wheel_velocity(velocity, velocity, velocity, velocity)
    elif key == ord('D') or key == ord('d'):
        # Turn right
        velocity = MAX_VELOCITY
        set_wheel_velocity(-velocity, velocity, -velocity, velocity)
    elif key == ord('A') or key == ord('a'):
        # Turn left
        velocity = MAX_VELOCITY
        set_wheel_velocity(velocity, -velocity, velocity, -velocity)
    elif key == ord('Q') or key == ord('q'):
        # Quit the program
        print("Exiting...")
        break
    else:
        # Stop the wheels when no key is pressed
        set_wheel_velocity(0, 0, 0, 0)

if __name__ == "__main__":
    run_robot()        