from controller import Robot, DistanceSensor

def run_robot():
    # Create the Robot instance
    robot = Robot()

    # Get simulation time step
    timestep = int(robot.getBasicTimeStep())

    # Get the DistanceSensor device
    sensor = robot.getDevice('sensor')
    sensor.enable(timestep)
    score = False


    # Get motor and keyboard devices
    motor = robot.getDevice('motor')

    # Set initial motor position
    initial_position = 0.0  # Assuming initial position is 0

    # Main control loop
    while robot.step(timestep) != -1:
        # Read DistanceSensor value
        sensor_value = sensor.getValue()
        current_time = robot.getTime()
        #print(sensor_value)
        # Check if the ball blocks the sensor (you may need to adjust the threshold based on your sensor's range)
        if sensor_value > 900 and not score:
            score = True
            print("得分")
        # Motor control (existing functionality)
        motor.setPosition(25 * 3.14159 / 180)

if __name__ == "__main__":
    run_robot()